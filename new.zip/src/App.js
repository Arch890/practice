import logo from "./logo.svg";
import "./App.css";
import EmployeeForm1 from "./pages/Employees/EmployeeForm";
import DemoMui from "./tableDemo";
import DashboardMui from "./dashboard";
import Login from "./Login";
import ForgetPassword from "./forget";
import SekeletonDashboard from "./SekeletonDash";
import RegistrationForm from "./RegistrationForm";
import Registration from "./register";
function App() {
  return (
    <>
      <DashboardMui/>
      {/* <Registration/> */}
      {/* <Login/> */}
      {/* <ForgetPassword/> */}
      {/* <SekeletonDashboard/> */}
    </>
  );
}

export default App;
