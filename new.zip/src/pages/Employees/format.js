import { Grid } from "@material-ui/core";

<grid container spacing={2}>
    <grid item xs="12">

    </grid>
</grid>